__version__ = "1!4.0.0a5"
__version_month__ = "May"
__version_year__ = "2017"
__version_name__ = "Riptalon"
